arr = []
 
# input values to list
arr = [12, 3, 4, 15]
 
# sum() is an inbuilt function in python that adds
# all the elements in list,set and tuples and returns
# the value
ans = sum(arr)
 
# display sum
print('Sum of the array is ', ans)