text = input("enter a name: ")
 
i=0
while i<10:
  i+=1
  print(text)