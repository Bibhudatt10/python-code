number = input("enter a number: ") 
number = int(number) 
print("The absolute value of the number", abs(number))