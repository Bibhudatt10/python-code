i = 1
while i <= 12:
  print(" {}. class".format(i))
  i += 1