def areaRectangle(a, b): 
    return (a * b) 
  
def perimeterRectangle(a, b): 
    return (2 * (a + b)) 
a = 5; 
b = 6; print ("Area = ", areaRectangle(a, b))

print ("Perimeter = ", perimeterRectangle(a, b))