total=0
while True:
  number = float(input("enter a number: "))
  if number ==0:
    break
  total+=number
print("The sum of the numbers: ",total)