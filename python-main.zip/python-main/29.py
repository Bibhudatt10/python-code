list=[35,48,52,57,68,84]
 
total = sum(list)
piece = len(list)
print(total/piece)