list=[3,1,2]
 
list[0]=1
list[1]=1
list[2]=2
 
print(list)