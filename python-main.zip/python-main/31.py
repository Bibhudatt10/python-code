text = input("enter a name: ")
 
for i in range(10):
  print(text)