number = input("enter a number: ")
sum=0
for numberofdigit in number:
  sum += int(numberofdigit)
 
print("the sum of the digits of the number:",sum)