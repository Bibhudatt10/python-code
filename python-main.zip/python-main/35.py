list=[3.14,2.54,"CPU","WINDOWS 10"]
 
print(list)