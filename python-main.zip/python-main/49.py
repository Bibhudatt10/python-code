# given the distance in km
distkm = 6.5
# conversion ratio
conversion_ratio = 0.62137
# converting the km to miles
distmiles = distkm*conversion_ratio
# print the distance in miles
print("The given distance", distkm, "km", "in miles=", distmiles,"miles")