number = input("enter an number: ")
number = int(number)
if number<0:
  number*=-1
print("The absolute value of the number: ",number)