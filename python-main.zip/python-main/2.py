visagrade = input('enter your visa grade : ')
finalgrade = input('enter your final grade : ')
average = (float(visagrade)*0.3)+(float(finalgrade)*0.7)
print("average :{0} ".format(average))
